function [y] = f(x)
% y = x^3/1000 + 3*sin(x);
y = 3*sin(x);
end