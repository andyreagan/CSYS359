function v = scaling_none(param,~)
v = param;