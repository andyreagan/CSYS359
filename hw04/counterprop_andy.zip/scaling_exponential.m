function v = scaling_exponential(param,iter)
v = param^iter;